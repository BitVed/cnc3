#include "generator_mode_list.h"
#include "xml_ext.h"

using namespace xml_ext;

void GeneratorMode::write(QXmlStreamWriter &xml) const {
    xml.writeStartElement("mode");
        writeDouble(xml, "drum_velocity", drum_velocity);
        writeDouble(xml, "pulse_width", pulse_width);
        writeDouble(xml, "pulse_ratio", pulse_ratio);
        writeDouble(xml, "voltage_level", voltage_level);
        writeDouble(xml, "current_level", current_level);
    xml.writeEndElement();
}

bool GeneratorMode::read(QXmlStreamReader& xml) {
    uint flags = 0;
    *this = GeneratorMode();

    while (!(xml.tokenType() == QXmlStreamReader::StartElement && xml.name() == "mode")) {
        if (xml.tokenType() == QXmlStreamReader::EndElement && xml.name() == "modes")
            return false;
        else if (xml.atEnd() || xml.hasError())
            return false;

        xml.readNext();
    }

    while (!(xml.tokenType() == QXmlStreamReader::EndElement && xml.name() == "mode")) {
        if (xml.atEnd() || xml.hasError())
            return false;

        if (xml.tokenType() == QXmlStreamReader::StartElement) {
            if (xml.name() == "drum_velocity")
                flags |= (uint)readFloat(xml, drum_velocity) << 0;
            else if (xml.name() == "pulse_width")
                flags |= (uint)readFloat(xml, pulse_width) << 1;
            else if (xml.name() == "pulse_ratio")
                flags |= (uint)readFloat(xml, pulse_ratio) << 2;
            else if (xml.name() == "voltage_level")
                flags |= (uint)readFloat(xml, voltage_level) << 3;
            else if (xml.name() == "current_level")
                flags |= (uint)readFloat(xml, current_level) << 4;
        }

        xml.readNext();
    }

    return flags == 0x1F;
}

//////////////////////////////////////////////////////////////////////////////

GeneratorModeList::GeneratorModeList() {}

GeneratorModeList::GeneratorModeList(const std::deque<GeneratorMode>& modes) {
    m_list = modes;
    m_error.clear();
}

void GeneratorModeList::write(QXmlStreamWriter& xml) const {
    xml.writeStartElement("modes");
        for (const GeneratorMode& m : m_list)
            m.write(xml);
    xml.writeEndElement();
}

bool GeneratorModeList::read(QXmlStreamReader& xml) {
    GeneratorMode m;
    m_list.clear();

    while (!(xml.tokenType() == QXmlStreamReader::StartElement && xml.name() == "modes")) {
        if (xml.atEnd() || xml.hasError())
            return false;

        xml.readNext();
    }

    while (1) {
        bool OK = m.read(xml);

        if (OK)
            m_list.push_back(m);
        else if (xml.tokenType() == QXmlStreamReader::EndElement && xml.name() == "modes")
            return true;
        else if (xml.atEnd() || xml.hasError())
            return false;
    }

    return true;
}

bool GeneratorModeList::writeXML(QFile& file) const {
    if (!file.isOpen())
        return false;

    QXmlStreamWriter xml(&file);
    xml.setAutoFormatting(true);
    xml.writeStartDocument();
        write(xml);
    xml.writeEndDocument();

    return true;
}

bool GeneratorModeList::readXML(QFile& file) {
    QXmlStreamReader xml;
    xml.setDevice(&file);

    while (xml.tokenType() != QXmlStreamReader::StartDocument) {
        if (xml.atEnd() || xml.hasError())
            return false;

        xml.readNext();
    }

    read(xml);

    if (xml.hasError()) {
        m_error = xml.errorString();
        return false;
    }

    return !m_list.empty();
}
