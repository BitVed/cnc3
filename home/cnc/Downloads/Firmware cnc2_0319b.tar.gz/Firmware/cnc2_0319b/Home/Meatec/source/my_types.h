#ifndef MY_TYPES_H
#define MY_TYPES_H

#include <stdint.h>
#include <stddef.h>
#include "main.h"

enum class AXIS : uint8_t {AXIS_X, AXIS_Y, AXIS_NUM};
enum class DIR : uint8_t {PLUS, MINUS};
enum class SLICING_PROFILE : uint8_t { RECT, CIRCLE };

namespace cnc_param {
#ifdef STONE
    constexpr static const double WIRE_DIAMETER = 0.33; // 0.4
    constexpr static const double SPEED = 1.8; // mm / min
#else
    constexpr static const double WIRE_DIAMETER = 0.18; // 0.2
    constexpr static const double SPEED = 3.6; // mm / min
#endif
    constexpr static const double SPEED_MAX = 18; // mm / min
    constexpr static const uint8_t DRUM_MIN = 1;
    constexpr static const uint8_t DRUM_MAX = 7;
}

struct snake_t {
    SLICING_PROFILE profile {SLICING_PROFILE::RECT};
    AXIS axis {AXIS::AXIS_X};
    uint8_t drum_vel {cnc_param::DRUM_MAX}, drum_vel_idle {cnc_param::DRUM_MIN};
    bool pause_ena {false};
    unsigned slices_num {20}, sections_num {20}, pause {30};
    double wireD {cnc_param::WIRE_DIAMETER}, width {40.0}, spacing {2.0}, step {-1.0}, speed_avg {cnc_param::SPEED}, speed_idle {cnc_param::SPEED_MAX};
};

struct comb_t {
    AXIS axis {AXIS::AXIS_X};
    uint8_t drum_vel {cnc_param::DRUM_MAX}, drum_vel_idle {cnc_param::DRUM_MIN};
    bool pause_ena {false};
    unsigned slots_num {20}, pause {30};
    double wireD {cnc_param::WIRE_DIAMETER}, depth {40.0}, step {-1.0}, speed {cnc_param::SPEED}, speed_idle {cnc_param::SPEED_MAX};
};

enum class OFFSET_SIDE : uint8_t { LEFT, RIGHT };
OFFSET_SIDE operator~(const OFFSET_SIDE& side);

struct offset_t {
    uint8_t mode_id {0};
    double offset {0};

    offset_t(uint8_t mode_id = 0, double offset = 0);
};

#endif // MY_TYPES_H
