<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>CenterWidget</name>
    <message>
        <location filename="center_widget.cpp" line="38"/>
        <source>Search radius</source>
        <translation>Радиус поиска</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="44"/>
        <location filename="center_widget.cpp" line="62"/>
        <location filename="center_widget.cpp" line="260"/>
        <location filename="center_widget.cpp" line="268"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="48"/>
        <source>Fine zone</source>
        <translation>Точная зона</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="56"/>
        <source>Rollback</source>
        <translation>Откат</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="104"/>
        <location filename="center_widget.cpp" line="276"/>
        <source>V</source>
        <translation>В</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="115"/>
        <source>Attempts</source>
        <translation>Попыток</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="272"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="280"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="147"/>
        <location filename="center_widget.cpp" line="373"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="27"/>
        <source>Center Mode</source>
        <translation>Режим центровки</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="28"/>
        <source>Line</source>
        <translation>Поиск края</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="29"/>
        <source>4 points (right angles)</source>
        <translation>По четырём точкам</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="30"/>
        <source>3 points (adjustable angles)</source>
        <translation>По трем точкам</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="92"/>
        <source>Drum Velocity</source>
        <translation>Скорость барабана</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="99"/>
        <source>Threshold</source>
        <translation>Порог</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="108"/>
        <source>Touches</source>
        <translation>Касаний</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="122"/>
        <location filename="center_widget.cpp" line="130"/>
        <location filename="center_widget.cpp" line="138"/>
        <source>Angle</source>
        <translation>Угол</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="157"/>
        <source>Reset position</source>
        <translation>Сброс положения</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="69"/>
        <source>Coarse speed</source>
        <translation>Грубая скорость</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="81"/>
        <source>Fine speed</source>
        <translation>Точная скорость</translation>
    </message>
    <message>
        <location filename="center_widget.cpp" line="77"/>
        <location filename="center_widget.cpp" line="89"/>
        <location filename="center_widget.cpp" line="148"/>
        <location filename="center_widget.cpp" line="284"/>
        <location filename="center_widget.cpp" line="384"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
</context>
<context>
    <name>CenteringWidget</name>
    <message>
        <source>mm</source>
        <translation type="obsolete">мм</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="obsolete">Скорость</translation>
    </message>
    <message>
        <source>mm/min</source>
        <translation type="obsolete">мм/мин</translation>
    </message>
    <message>
        <source>V</source>
        <translation type="obsolete">В</translation>
    </message>
    <message>
        <source>HV</source>
        <translation type="obsolete">ВН</translation>
    </message>
    <message>
        <source>Wire</source>
        <translation type="obsolete">Проволока</translation>
    </message>
</context>
<context>
    <name>CncComThread</name>
    <message>
        <location filename="cnc_com_thread.cpp" line="837"/>
        <source>Read response timeout</source>
        <oldsource>Wait read response timeout</oldsource>
        <translation>Таймаут чтения</translation>
    </message>
    <message>
        <location filename="cnc_com_thread.cpp" line="842"/>
        <source>Write request timeout</source>
        <oldsource>Wait write request timeout</oldsource>
        <translation>Таймаут записи</translation>
    </message>
</context>
<context>
    <name>CombWidget</name>
    <message>
        <source>Comb</source>
        <translation type="vanished">Гребёнка</translation>
    </message>
    <message>
        <source>Slots</source>
        <translation type="vanished">Прорези</translation>
    </message>
    <message>
        <source>Wire diameter</source>
        <translation type="vanished">Диаметр проволоки</translation>
    </message>
    <message>
        <source>Slots depth</source>
        <translation type="vanished">Глубина прорезей</translation>
    </message>
    <message>
        <source>signed value</source>
        <translation type="vanished">число со знаком</translation>
    </message>
    <message>
        <source>Step</source>
        <translation type="vanished">Шаг</translation>
    </message>
    <message>
        <source>Slots number</source>
        <translation type="vanished">Количество прорезей</translation>
    </message>
    <message>
        <source>Cut speed</source>
        <oldsource>Cutting speed</oldsource>
        <translation type="vanished">Скорость реза</translation>
    </message>
    <message>
        <source>Drum velocity</source>
        <translation type="vanished">Скорость барабана</translation>
    </message>
    <message>
        <source>mm</source>
        <translation type="vanished">мм</translation>
    </message>
    <message>
        <source>mm/min</source>
        <translation type="vanished">мм/мин</translation>
    </message>
    <message>
        <source>Axis</source>
        <translation type="vanished">Ось</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation type="vanished">Генерировать</translation>
    </message>
    <message>
        <source>Generate contour</source>
        <translation type="vanished">Генерировать контур</translation>
    </message>
    <message>
        <source>Comb generate error</source>
        <translation type="vanished">Ошибка генерации прорезей</translation>
    </message>
</context>
<context>
    <name>ContourTableModel</name>
    <message>
        <location filename="contour_table_model.cpp" line="51"/>
        <source>XY Plane</source>
        <translation>Плоскость XY</translation>
    </message>
    <message>
        <location filename="contour_table_model.cpp" line="53"/>
        <source>UV Plane</source>
        <translation>Плоскость UV</translation>
    </message>
</context>
<context>
    <name>FormCenter</name>
    <message>
        <location filename="form_center.cpp" line="74"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <source>Go to Home panel</source>
        <oldsource>Goto Home panel</oldsource>
        <translation type="vanished">Переход на главную панель</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="10"/>
        <source>Centring Panel</source>
        <translation>Центровка</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="75"/>
        <source>Go to the Home panel</source>
        <translation>Переход на главную панель</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="78"/>
        <source>X-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="79"/>
        <source>Decrease X</source>
        <translation>Уменьшение X</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="81"/>
        <source>X+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="82"/>
        <source>Increase X</source>
        <translation>Увеличение X</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="84"/>
        <source>Y-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="85"/>
        <source>Decrease Y</source>
        <translation>Уменьшение Y</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="87"/>
        <source>Y+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="88"/>
        <source>Increase Y</source>
        <translation>Увеличение Y</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="90"/>
        <source>Center</source>
        <translation>Центр</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="91"/>
        <source>Find a center</source>
        <oldsource>Find center</oldsource>
        <translation>Найти центр</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="101"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="103"/>
        <source>Enable weak high voltage</source>
        <translation>Включение слабого высокого напряжения</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="111"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <source>Find the center</source>
        <translation type="vanished">Центровка</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="105"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="108"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="form_center.cpp" line="110"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormCentering</name>
    <message>
        <source>Home</source>
        <translation type="vanished">Главная</translation>
    </message>
    <message>
        <source>Goto Home panel</source>
        <translation type="vanished">Переход на главную панель</translation>
    </message>
    <message>
        <source>Decrease X</source>
        <translation type="vanished">Уменьшение X</translation>
    </message>
    <message>
        <source>Increase X</source>
        <translation type="vanished">Увеличение X</translation>
    </message>
    <message>
        <source>Decrease Y</source>
        <translation type="vanished">Уменьшение Y</translation>
    </message>
    <message>
        <source>Increase Y</source>
        <translation type="vanished">Увеличение Y</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="vanished">Центр</translation>
    </message>
    <message>
        <source>Find the center</source>
        <translation type="vanished">Центровка</translation>
    </message>
    <message>
        <source>Hold</source>
        <translation type="vanished">Держать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Отмена</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="vanished">Помощь</translation>
    </message>
</context>
<context>
    <name>FormContour</name>
    <message>
        <location filename="form_contour.cpp" line="25"/>
        <source>Contour Editor</source>
        <translation>Редактор контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="66"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="70"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="71"/>
        <source>Open project from file</source>
        <translation>Открыть проект из файла</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="74"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="78"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="100"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="104"/>
        <source>Load XY</source>
        <translation>Загр. XY</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="107"/>
        <source>Load UV</source>
        <translation>Загр. UV</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="111"/>
        <source>Passes</source>
        <translation>Проходы</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="81"/>
        <source>Generate</source>
        <translation>Генер.</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="99"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="67"/>
        <source>Go to the Home panel</source>
        <oldsource>Go to the home panel</oldsource>
        <translation>Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="75"/>
        <source>Save project in the current file</source>
        <translation>Сохранить проект в текущий файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="79"/>
        <source>Save project as a new file</source>
        <translation>Сохранить проект в новый файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="105"/>
        <source>Load XY contour from DXF file</source>
        <oldsource>Load XY contour from a DXF file</oldsource>
        <translation>Загрузить контур реза в проскости XY из DXF файла</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="108"/>
        <source>Load UV contour from DXF file</source>
        <oldsource>Load UV contour from a DXF file</oldsource>
        <translation>Загрузить контур реза в проскости UV из DXF файла</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="112"/>
        <source>Cut settings. Passes adjustments and cut modes</source>
        <translation>Настройки реза. Настройки проходов и режимов реза</translation>
    </message>
    <message>
        <source>Open a project</source>
        <translation type="vanished">Открыть проект</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="115"/>
        <source>Load DXF file</source>
        <translation>Загрузить DXF файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="121"/>
        <source>Adjust cut settings</source>
        <translation>Настроить параметры реза</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="227"/>
        <source>Entry Line</source>
        <translation>Линия захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="228"/>
        <source>Add a new cutline before the first segment</source>
        <translation>Добавить новую линию захода перед первым сегментом контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="244"/>
        <source>Set First</source>
        <translation>Первый</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="245"/>
        <source>Set the selected segment the first in the contour</source>
        <translation>Сделать выбранный сегмент первым в контуре</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="247"/>
        <source>Change Direction</source>
        <translation>Изм. направление</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="256"/>
        <source>Use selected segment as the Entry line</source>
        <translation>Использовать выделенный сегмент как линию захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="258"/>
        <source>Mark as the Last segment</source>
        <translation>Пометить как последний</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="357"/>
        <location filename="form_contour.cpp" line="979"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="369"/>
        <source>Contour: Open DXF file error</source>
        <translation>Контур: Ошибка открытия файла DXF</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="375"/>
        <source>Bottom layer is loaded successfully</source>
        <translation>Нижний слой загружен успешно</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="800"/>
        <source>No contour. There is only a cutline</source>
        <translation>Нет контура, имеется только линия захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="977"/>
        <source>Open project</source>
        <translation>Открыть проект из файла</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="976"/>
        <location filename="form_contour.cpp" line="1080"/>
        <source>Project files</source>
        <translation>Файлы проектов</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="991"/>
        <source>Contour: Open project file error</source>
        <translation>Контур: Ошибка открытия файла проекта</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="1027"/>
        <source>Contour: Parse project file error</source>
        <oldsource>Cut settings: Parse file error</oldsource>
        <translation>Контур: Ошибка разбора файла проекта</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="1045"/>
        <source>Contour: Save project file error</source>
        <translation>Контур: Ошибка сохранения проекта</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="1078"/>
        <source>Save project</source>
        <translation>Сохранить проект</translation>
    </message>
    <message>
        <source>Save current project</source>
        <translation type="vanished">Сохранить проект</translation>
    </message>
    <message>
        <source>Save current project with a new name</source>
        <translation type="vanished">Сохранить проект в новый файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="114"/>
        <source>Load DXF</source>
        <translation>Загр. DXF</translation>
    </message>
    <message>
        <source>Load a DXF file</source>
        <translation type="vanished">Загрузить DXF файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="120"/>
        <source>Adjust</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <source>Adjust the contour</source>
        <translation type="vanished">Параметры обработки</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="82"/>
        <source>Generate G-code</source>
        <translation>Генерировать G-код</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="178"/>
        <source>Contours</source>
        <translation>Контуры</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="179"/>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="224"/>
        <source>New Contour</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Add Cutline</source>
        <translation type="vanished">Линия захода</translation>
    </message>
    <message>
        <source>Add new cutline before the first segment</source>
        <translation type="vanished">Добавить линию захода перед первым сегментом контура</translation>
    </message>
    <message>
        <source>Set as the first segment in the contour</source>
        <translation type="vanished">Сделать выбранный сегмент первым в контуре</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="255"/>
        <source>Use as Entry line</source>
        <oldsource>Use segment as cutline</oldsource>
        <translation>Исп. как линия захода</translation>
    </message>
    <message>
        <source>Mark as the last segment</source>
        <translation type="vanished">Отметить выбранный сегмент как послений в контуре</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="385"/>
        <source>Removed unconnected segments from DXF</source>
        <translation>Удаленные не соединенные сегменты в файле DXF</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="395"/>
        <source>Removed extra tails from DXF</source>
        <translation>Удаленные лишнии хвосты из файла DXF</translation>
    </message>
    <message>
        <source>Add new cutline before first segment</source>
        <translation type="vanished">Добавить линию захода перед первым сегментом контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="230"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="231"/>
        <source>Delete selected contour</source>
        <translation>Удалить выбранный контур</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="233"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="234"/>
        <source>Clear all contours</source>
        <translation>Очистить все контуры</translation>
    </message>
    <message>
        <source>First</source>
        <translation type="vanished">Первый</translation>
    </message>
    <message>
        <source>Set as first segment in contour</source>
        <translation type="vanished">Сделать первым элементом в контуре</translation>
    </message>
    <message>
        <source>Change direction</source>
        <translation type="vanished">Изм. направление</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="248"/>
        <source>Change contour direction</source>
        <translation>Изменить направление обхода контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="251"/>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <source>Use as Cutline</source>
        <translation type="vanished">Использовать как линию захода</translation>
    </message>
    <message>
        <source>Use segment as Cutline</source>
        <translation type="vanished">Использовать сегмент  как линию захода</translation>
    </message>
    <message>
        <source>Set as Cutline</source>
        <translation type="vanished">Сделать линией захода</translation>
    </message>
    <message>
        <source>Set segment as Cutline</source>
        <translation type="vanished">Сделать сегмент линией захода</translation>
    </message>
    <message>
        <source>Mark as last segment</source>
        <oldsource>Set as last segment</oldsource>
        <translation type="vanished">Пометить как  выходной сегмент</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="261"/>
        <source>Rotate</source>
        <translation>Поворот</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="262"/>
        <source>Rotate the contour</source>
        <translation>Повернуть контур</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="264"/>
        <source>Flip Left-Right</source>
        <translation>Перевернуть слева-направо</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="265"/>
        <source>Flip the contour Left-Right</source>
        <translation>Перевернуть контур слево-направо</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="267"/>
        <source>Flip Up-Down</source>
        <translation>Перевернуть сверху-вниз</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="268"/>
        <source>Flip the contour Up-Down</source>
        <translation>Перевернуть контур сверху-вниз</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="270"/>
        <source>Resize</source>
        <translation>Изм. размер</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="271"/>
        <source>Resize the contour</source>
        <translation>Изменить размер контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="355"/>
        <source>Open DXF file</source>
        <translation>Открыть DXF файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="354"/>
        <source>DXF files</source>
        <translation>Файлы DXF</translation>
    </message>
    <message>
        <source>Bottom layer loaded successfully</source>
        <translation type="vanished">Нижний контур загружен успешно</translation>
    </message>
    <message>
        <source>Removed unconnected segments from Dxf</source>
        <translation type="vanished">Удалены не подсоединенные сегменты из Dxf</translation>
    </message>
    <message>
        <source>Removed extra tails from Dxf</source>
        <translation type="vanished">Удалены лишние хвосты из Dxf</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="405"/>
        <source>Bottom layer DXF segments sorting error</source>
        <translation>Ошибка сортировки нижнего контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="413"/>
        <source>Bottom layer DXF parsing error</source>
        <translation>Ошибка файла нижнего контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="793"/>
        <source>No contour</source>
        <translation>Нет контура</translation>
    </message>
    <message>
        <source>No contour. Only cutline</source>
        <translation type="vanished">Нет контура. Только линия входа</translation>
    </message>
</context>
<context>
    <name>FormEdit</name>
    <message>
        <location filename="form_edit.cpp" line="84"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="85"/>
        <source>Go to the Home panel</source>
        <oldsource>Go to the home panel</oldsource>
        <translation>Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="88"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="89"/>
        <source>Create a new G-code file</source>
        <translation>Создать новый файл G-кода</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="92"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="96"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="101"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="102"/>
        <source>Save G-code file with a new name</source>
        <translation>Сохранить G-код в новый файл</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="104"/>
        <source>Plot</source>
        <translation>Чертёж</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="105"/>
        <source>Show the plot</source>
        <translation>Показать чертёж</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="112"/>
        <source>to Contour</source>
        <translation>в Контур</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="113"/>
        <source>Convert a G-code file into a contour</source>
        <oldsource>Convert G-code file into a contour</oldsource>
        <translation>Преобразовать файл G-кода в контур</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="128"/>
        <source>Run</source>
        <translation>Работа</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="129"/>
        <source>Open Work panel</source>
        <oldsource>Open Run panel</oldsource>
        <translation>Перейти в рабочую панель</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="132"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="133"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="233"/>
        <source>G-code Editor: Open file error</source>
        <oldsource>G-code Editor: Open file Error</oldsource>
        <translation>Редактор G-кода: Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="255"/>
        <source>G-code Editor: Save file error</source>
        <translation>Редактор G-кода: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="344"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="345"/>
        <source>The contour is not empty</source>
        <translation>Контур не пустой</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="346"/>
        <source>Do you want to overwrite it?</source>
        <translation>Вы хотите перезаписать его?</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="347"/>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="348"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="93"/>
        <location filename="form_edit.cpp" line="218"/>
        <source>Open G-code file</source>
        <translation>Открыть файл G-кода</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="20"/>
        <source>G-code Editor</source>
        <translation>Редактор G-кода</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="220"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="217"/>
        <location filename="form_edit.cpp" line="285"/>
        <source>G-code files</source>
        <oldsource>G-code (*.nc *.NC)</oldsource>
        <translation>G-код файлы</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="vanished">Все файлы (*)</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="97"/>
        <location filename="form_edit.cpp" line="283"/>
        <source>Save G-code file</source>
        <translation>Сохранить G-код</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="301"/>
        <source>Play</source>
        <translation>Проиграть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="307"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
</context>
<context>
    <name>FormHelp</name>
    <message>
        <location filename="form_help.cpp" line="7"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="34"/>
        <source>Help file is not found</source>
        <oldsource>Help file not found</oldsource>
        <translation>Файл помощи не найден</translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="51"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="52"/>
        <source>Quit Help</source>
        <translation>Выйти из помощи</translation>
    </message>
    <message>
        <source>Exit Help</source>
        <translation type="vanished">Выйти из помощи</translation>
    </message>
    <message>
        <source>Quit the help panel</source>
        <translation type="vanished">Выйти из панели помощи</translation>
    </message>
</context>
<context>
    <name>FormHome</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Главная панель</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="14"/>
        <location filename="form_home.cpp" line="110"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="27"/>
        <source>Main</source>
        <translation>Главная панель</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="35"/>
        <source>Slots</source>
        <translation>Прорези</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="113"/>
        <source>Contour</source>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="116"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="119"/>
        <source>Run</source>
        <translation>Работа</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Настройки</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="330"/>
        <source>Serial port is not found</source>
        <translation>Последовательный порт не найден</translation>
    </message>
    <message>
        <source>G-code Recovery</source>
        <translation type="vanished">Восстановить G-код</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="135"/>
        <source>Recovery</source>
        <translation>Восстан.</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="125"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="145"/>
        <source>Test</source>
        <translation>Тест</translation>
    </message>
    <message>
        <source>Minimize Program</source>
        <translation type="vanished">Свернуть программу</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="152"/>
        <source>Minimize</source>
        <translation>Свернуть</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="155"/>
        <source>Shutdown</source>
        <translation>Выкл.</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="156"/>
        <source>Turn off the computer</source>
        <translation>Выключить компьютер</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="159"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="vanished">Приветствие</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="31"/>
        <source>Slicing</source>
        <translation>Нарезка</translation>
    </message>
    <message>
        <source>Comb</source>
        <translation type="vanished">Гребёнка</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="40"/>
        <source>UV Sizing</source>
        <translation>Калибровка UV</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="114"/>
        <source>Load and edit contour</source>
        <oldsource>Load and edit a contour</oldsource>
        <translation>Редактировать контур</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="117"/>
        <source>Open G-code editor</source>
        <translation>Редактировать программу G-код</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="120"/>
        <source>Open Work panel</source>
        <oldsource>Open Run panel</oldsource>
        <translation>Открыть рабочую панель</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="122"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="123"/>
        <source>Change CNC settings</source>
        <translation>Изменить настройки ЧПУ</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="126"/>
        <source>Manual ruling of the CNC</source>
        <translation>Открыть панель ручного управления</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="129"/>
        <source>Center</source>
        <translation>Центр</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="136"/>
        <source>Recovery the last job</source>
        <translation>Восстановить последнее прерванное задание</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="146"/>
        <source>Diagnostic Panel</source>
        <translation>Панель диагностики</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="153"/>
        <source>Minimize CNC program and open Linux desktop</source>
        <translation>Свернуть программу и показать рабочий стол</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="160"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="233"/>
        <source>Power off dialog</source>
        <oldsource>Shut down dialog</oldsource>
        <translation>Выключение компьютера</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="236"/>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="237"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Shut down</source>
        <translation type="vanished">Выключение</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="234"/>
        <source>Are you sure you want to turn off the computer now</source>
        <translation>Вы уверены, что хотите выключить компьютер</translation>
    </message>
    <message>
        <source>Shutdown CNC</source>
        <translation type="vanished">Выключить ЧПУ</translation>
    </message>
    <message>
        <source>Info</source>
        <oldsource>Info: </oldsource>
        <translation type="vanished">Информация</translation>
    </message>
    <message>
        <source>Connecting...</source>
        <translation type="vanished">Соединение...</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="314"/>
        <source>Connecting</source>
        <translation>Соединение</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="314"/>
        <source>Attempt</source>
        <translation>Попытка</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="328"/>
        <location filename="form_home.cpp" line="345"/>
        <source>Error</source>
        <oldsource>Error: </oldsource>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>UART port is not found</source>
        <translation type="vanished">Последовательный порт не найден</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="347"/>
        <source>No connection. Check conection between computer and CNC board</source>
        <translation>Нет соединения. Проверьте соединение между компьютером и платой ЧПУ</translation>
    </message>
    <message>
        <location filename="form_home.h" line="39"/>
        <source>Meatec CNC Machine</source>
        <translation>ЧПУ компании Меатэк</translation>
    </message>
    <message>
        <location filename="form_home.h" line="42"/>
        <source>stone</source>
        <translation>камнерез</translation>
    </message>
    <message>
        <location filename="form_home.h" line="47"/>
        <source>Application</source>
        <oldsource>Application </oldsource>
        <translation>Приложение</translation>
    </message>
    <message>
        <location filename="form_home.h" line="47"/>
        <source>built on</source>
        <translation>от</translation>
    </message>
    <message>
        <source>on</source>
        <translation type="vanished">от</translation>
    </message>
    <message>
        <source>from </source>
        <translation type="vanished">от </translation>
    </message>
    <message>
        <source>MODEL_NAME</source>
        <translation type="vanished">ИМЯ_МОДЕЛИ</translation>
    </message>
    <message>
        <source>Model</source>
        <translation type="vanished">Модель</translation>
    </message>
</context>
<context>
    <name>FormPasses</name>
    <message>
        <location filename="form_passes.cpp" line="15"/>
        <source>Cut settings</source>
        <oldsource>Cutting settings</oldsource>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="57"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="58"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="67"/>
        <source>Cut Times</source>
        <translation>Число проходов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="84"/>
        <source>Overlap</source>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="87"/>
        <location filename="form_passes.cpp" line="110"/>
        <location filename="form_passes.cpp" line="137"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <source>Indent Width</source>
        <oldsource>Tab Width</oldsource>
        <translation type="vanished">Длина недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="107"/>
        <source>Offset in pass</source>
        <translation>Смещение на проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="117"/>
        <source>Mode in pass</source>
        <translation>Режим на проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="125"/>
        <source>Onepass</source>
        <oldsource>Onepass Cutting</oldsource>
        <translation>Однопроходный</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="126"/>
        <source>Multipass</source>
        <oldsource>Multipass Cutting</oldsource>
        <translation>Многопроходный</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation type="vanished">Недорез</translation>
    </message>
    <message>
        <source>Indent Offset</source>
        <oldsource>Tab Offset</oldsource>
        <translation type="vanished">Смещение при недорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="142"/>
        <source>Cutline Mode</source>
        <translation>Режим линии захода</translation>
    </message>
    <message>
        <source>Indent Mode</source>
        <oldsource>Tab Mode</oldsource>
        <translation type="vanished">Режим при недорезе</translation>
    </message>
    <message>
        <source>Indent Pause</source>
        <oldsource>Tab Pause</oldsource>
        <translation type="vanished">Пауза после недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="92"/>
        <source>Tab Width</source>
        <translation>Ширина недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="128"/>
        <source>Workpiece Tab</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="134"/>
        <source>Tab Offset</source>
        <translation>Смещение для недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="146"/>
        <source>Tab Mode</source>
        <translation>Режим работы для недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="150"/>
        <source>Tab Pause</source>
        <translation>Сделать паузу перед недорезом</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="152"/>
        <source>Pump On Pause</source>
        <oldsource>Pump Delay</oldsource>
        <translation>Задерка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="155"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="159"/>
        <source>Pump On Stop</source>
        <oldsource>Pump Pause</oldsource>
        <translation>Остановка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="334"/>
        <source>Generator Operation Modes</source>
        <translation>Режимы работы генератора</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="346"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="347"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="348"/>
        <location filename="form_passes.cpp" line="645"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="349"/>
        <location filename="form_passes.cpp" line="649"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="351"/>
        <source>Save As</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="429"/>
        <location filename="form_passes.cpp" line="533"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="441"/>
        <source>Operation modes: Open file error</source>
        <oldsource>Modes: Open file error</oldsource>
        <translation>Режимы работы: Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="447"/>
        <source>Operation modes: Parse file error</source>
        <oldsource>Modes: Parse file error</oldsource>
        <translation>Режимы работы: Ошибка разбора файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="477"/>
        <source>Operation modes: Save file error</source>
        <oldsource>Modes: Save file error</oldsource>
        <translation>Режимы работы: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="531"/>
        <source>Open cut settings file</source>
        <translation>Открыть файл параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="654"/>
        <source>Save cut settings into a new file</source>
        <translation>Сохранить параметры реза как новый файл</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="530"/>
        <location filename="form_passes.cpp" line="628"/>
        <source>Cut settings files</source>
        <translation>Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="545"/>
        <source>Cut settings: Open file error</source>
        <translation>Настройки реза: Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="577"/>
        <source>Cut settings: Parse file error</source>
        <translation>Настройки реза: Ошибка разбора файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="595"/>
        <source>Cut settigns: Save file error</source>
        <translation>Настройки река: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="626"/>
        <location filename="form_passes.cpp" line="650"/>
        <source>Save cut settings</source>
        <translation>Сохранить параметры реза</translation>
    </message>
    <message>
        <source>Factory</source>
        <translation type="vanished">Сброс</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="427"/>
        <source>Open modes file</source>
        <translation>Открыть файл режимов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="426"/>
        <location filename="form_passes.cpp" line="503"/>
        <source>Modes files</source>
        <oldsource>Modes file (*.xmd *.XMD)</oldsource>
        <translation>Файлы режимов</translation>
    </message>
    <message>
        <source>Modes: Open File Error</source>
        <translation type="vanished">Режимы: Ошибка открытия файла</translation>
    </message>
    <message>
        <source>Modes: Parse File Error</source>
        <translation type="vanished">Режимы: Ошибка разбора файла</translation>
    </message>
    <message>
        <source>Modes: Save File Error</source>
        <translation type="vanished">Режимы: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="501"/>
        <source>Save modes file</source>
        <translation>Сохранение режимов работы</translation>
    </message>
    <message>
        <source>Cutting: Save File Error</source>
        <translation type="vanished">Рез: Ошибка сохранения файла</translation>
    </message>
    <message>
        <source>Save cutting settings</source>
        <translation type="vanished">Сохранение параметров реза</translation>
    </message>
    <message>
        <source>Cutting settings files</source>
        <oldsource>Cutting settings file (*.xct *.XCT)</oldsource>
        <translation type="vanished">Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="641"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="642"/>
        <source>Return to Contour editor</source>
        <oldsource>Return to Contour panel</oldsource>
        <translation>Вернуться в панель редактора контура реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="646"/>
        <source>Open cut settings from file</source>
        <translation>Открыть параметры реза из файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="653"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="352"/>
        <location filename="form_passes.cpp" line="656"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <source>Indent</source>
        <translation type="vanished">Недорез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="657"/>
        <source>Set default values</source>
        <translation>Установить значения по умолчанию</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="683"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="684"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="721"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>FormPassesStone</name>
    <message>
        <source>Contour Adjustments</source>
        <translation type="vanished">Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="15"/>
        <location filename="form_passes_stone.cpp" line="16"/>
        <source>Cut settings</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="58"/>
        <source>Additional Offset</source>
        <translation>Дополнительное смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="61"/>
        <location filename="form_passes_stone.cpp" line="91"/>
        <location filename="form_passes_stone.cpp" line="134"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="69"/>
        <location filename="form_passes_stone.cpp" line="99"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="70"/>
        <location filename="form_passes_stone.cpp" line="100"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="88"/>
        <source>Wire Offset</source>
        <oldsource>Cutting Offset</oldsource>
        <translation>Смещение проволоки</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="131"/>
        <source>Overlap</source>
        <oldsource>Overlapping</oldsource>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="228"/>
        <source>Add a pause after each segment</source>
        <translation>Добавить паузу после каждого сегмента</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="713"/>
        <source>Open cut settings file</source>
        <translation>Открыть файл параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="848"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="712"/>
        <location filename="form_passes_stone.cpp" line="793"/>
        <source>Cut settings files</source>
        <translation>Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="715"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="727"/>
        <source>Cut settings: Open file error</source>
        <translation>Параметры  реза: Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="743"/>
        <source>Cut settings: Parse file error</source>
        <translation>Параметры реза: Ошибка разбора файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="760"/>
        <source>Cut settings: Save file error</source>
        <translation>Параметры реза: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="791"/>
        <location filename="form_passes_stone.cpp" line="814"/>
        <source>Save cut settings</source>
        <translation>Сохранить параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="806"/>
        <source>Return to Contour editor</source>
        <translation>Вернуться в панель редактора контура реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="810"/>
        <source>Open cut settings from file</source>
        <oldsource>Open cut settings from a file</oldsource>
        <translation>Открыть параметры реза из файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="818"/>
        <source>Save cut settings into a new file</source>
        <translation>Сохранить параметры реза как новый файл</translation>
    </message>
    <message>
        <source>Open contour settings from the file</source>
        <translation type="vanished">Открыть настройки обработки из файла</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation type="vanished">Недорез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="147"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="149"/>
        <source>Last segment</source>
        <translation>Последний сегмент</translation>
    </message>
    <message>
        <source>Indent Pause</source>
        <oldsource>Tab Pause</oldsource>
        <translation type="vanished">Остановка перед недорезом</translation>
    </message>
    <message>
        <source>Pump On Delay</source>
        <translation type="vanished">Пауза по вкл. насоса</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="230"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <source>Pump On Pause</source>
        <translation type="vanished">Остановка по вкл. насоса</translation>
    </message>
    <message>
        <source>Indent</source>
        <translation type="vanished">Недорез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="139"/>
        <source>Tab width</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="207"/>
        <source>Tab Pause</source>
        <translation>Сделать паузу перед недорезом</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="219"/>
        <source>Cut Speed</source>
        <oldsource>Cutting Speed</oldsource>
        <translation>Скорость реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="222"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <source>Add pause after each segment</source>
        <translation type="vanished">Добавить паузу после каждого сегмента</translation>
    </message>
    <message>
        <source>Cutting: Save File Error</source>
        <translation type="vanished">Рез: Ошибка сохранения файла</translation>
    </message>
    <message>
        <source>Save cutting settings</source>
        <translation type="vanished">Сохранение параметров реза</translation>
    </message>
    <message>
        <source>Cutting settings files</source>
        <oldsource>Cutting settings file</oldsource>
        <translation type="vanished">Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="805"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <source>Return to the Contour editor</source>
        <oldsource>Return to the Contour panel</oldsource>
        <translation type="vanished">Вернуться в редактор контура</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="809"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <source>Open contour settings from a file</source>
        <translation type="vanished">Открыть параметры контура из файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="813"/>
        <source>Save</source>
        <translation>Сохранение</translation>
    </message>
    <message>
        <source>Save contour settings</source>
        <translation type="vanished">Сохранить параметры контура</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="817"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <source>Save contour settings into a new file</source>
        <translation type="vanished">Сохранить параметры контура в новый файл</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="820"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="821"/>
        <source>Set default values</source>
        <translation>Установить значения по умолчанию</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="847"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormPult</name>
    <message>
        <location filename="form_pult.cpp" line="19"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="76"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <source>Go to Home panel</source>
        <oldsource>Goto Home panel</oldsource>
        <translation type="vanished">Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="80"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <source>Wire</source>
        <translation type="vanished">Проволока</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="10"/>
        <source>CNC Pult</source>
        <translation>Пульт ЧПУ</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="77"/>
        <source>Go to the Home panel</source>
        <translation>Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="81"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="84"/>
        <source>Break</source>
        <translation>Обрыв</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="86"/>
        <source>Wire break control on/off</source>
        <translation>Вкл./выкл. контроль обрыва проволоки</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="88"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="90"/>
        <source>Pump on/off</source>
        <translation>Вкл./выкл. насос</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="92"/>
        <location filename="form_pult.cpp" line="264"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="94"/>
        <source>Wire drum on/off</source>
        <translation>Вкл./выкл. вращение барабана</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="96"/>
        <location filename="form_pult.cpp" line="113"/>
        <location filename="form_pult.cpp" line="127"/>
        <location filename="form_pult.cpp" line="141"/>
        <location filename="form_pult.cpp" line="155"/>
        <source>DEC</source>
        <translation>Умен.</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="97"/>
        <source>Drum velocity decrement</source>
        <translation>Уменьшить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="99"/>
        <location filename="form_pult.cpp" line="120"/>
        <location filename="form_pult.cpp" line="134"/>
        <location filename="form_pult.cpp" line="148"/>
        <location filename="form_pult.cpp" line="162"/>
        <source>INC</source>
        <translation>Увел.</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="100"/>
        <source>Drum velocity increment</source>
        <translation>Увеличить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="104"/>
        <location filename="form_pult.cpp" line="270"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="106"/>
        <source>Enable high voltage if drum and pump enabled</source>
        <translation>Вкл./выкл. высокого напряжения</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="266"/>
        <source>Width</source>
        <oldsource>Width: </oldsource>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="268"/>
        <source>Ratio</source>
        <oldsource>Ratio: </oldsource>
        <translation>Скважность</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="272"/>
        <source>Current</source>
        <oldsource>Current: </oldsource>
        <translation>Ток</translation>
    </message>
</context>
<context>
    <name>FormRun</name>
    <message>
        <location filename="form_run.cpp" line="89"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="90"/>
        <source>Go to the Home panel</source>
        <oldsource>Go to Home panel</oldsource>
        <translation>Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="93"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <source>Wire</source>
        <translation type="vanished">Проволока</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="12"/>
        <source>Work Panel</source>
        <oldsource>Run Panel</oldsource>
        <translation>Рабочая панель</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="94"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="97"/>
        <source>Break</source>
        <translation>Обрыв</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="99"/>
        <source>Wire break control on/off</source>
        <oldsource>Wire control on/off</oldsource>
        <translation>Вкл./выкл. контроль обрыва проволоки</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="104"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="106"/>
        <source>Pump on/off</source>
        <translation>Вкл./выкл. насос</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="108"/>
        <location filename="form_run.cpp" line="305"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="110"/>
        <source>Wire drum on/off</source>
        <translation>Вкл./выкл. вращение барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="112"/>
        <location filename="form_run.cpp" line="128"/>
        <location filename="form_run.cpp" line="142"/>
        <location filename="form_run.cpp" line="156"/>
        <location filename="form_run.cpp" line="170"/>
        <source>DEC</source>
        <translation>Умен.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="113"/>
        <source>Drum velocity decrement</source>
        <translation>Уменьшить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="115"/>
        <location filename="form_run.cpp" line="135"/>
        <location filename="form_run.cpp" line="149"/>
        <location filename="form_run.cpp" line="163"/>
        <location filename="form_run.cpp" line="177"/>
        <source>INC</source>
        <translation>Увел.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="116"/>
        <source>Drum velocity increment</source>
        <translation>Увеличить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="121"/>
        <location filename="form_run.cpp" line="311"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="307"/>
        <source>Width</source>
        <oldsource>Width: </oldsource>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="309"/>
        <source>Ratio</source>
        <oldsource>Ratio: </oldsource>
        <translation>Скважность</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="313"/>
        <source>Current</source>
        <oldsource>Current: </oldsource>
        <translation>Ток</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="469"/>
        <location filename="form_run.cpp" line="478"/>
        <location filename="form_run.cpp" line="552"/>
        <source>G-code size is too big</source>
        <translation>Размер G-кода слишком большой</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="470"/>
        <location filename="form_run.cpp" line="479"/>
        <location filename="form_run.cpp" line="485"/>
        <location filename="form_run.cpp" line="543"/>
        <location filename="form_run.cpp" line="553"/>
        <source>G-code size</source>
        <translation>Размер G-кода</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="470"/>
        <location filename="form_run.cpp" line="471"/>
        <location filename="form_run.cpp" line="479"/>
        <location filename="form_run.cpp" line="485"/>
        <location filename="form_run.cpp" line="486"/>
        <location filename="form_run.cpp" line="543"/>
        <location filename="form_run.cpp" line="544"/>
        <location filename="form_run.cpp" line="553"/>
        <source>bytes</source>
        <translation>байт</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="471"/>
        <location filename="form_run.cpp" line="479"/>
        <location filename="form_run.cpp" line="486"/>
        <location filename="form_run.cpp" line="544"/>
        <location filename="form_run.cpp" line="553"/>
        <source>CNC program array size</source>
        <translation>Размер памяти ЧПУ</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="510"/>
        <source>Read G-code error</source>
        <translation>Ошибка чтения G-кода</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="626"/>
        <location filename="form_run.cpp" line="638"/>
        <location filename="form_run.cpp" line="649"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="626"/>
        <source>No G-code</source>
        <translation>Нет  G-кода</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="638"/>
        <source>G-code normalization error</source>
        <translation>Ошибка нормализации G-кода</translation>
    </message>
    <message>
        <source>G-code error</source>
        <translation type="vanished">Ошибка G-код</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="649"/>
        <source>No CNC connection</source>
        <translation>Нет связи с ЧПУ</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="696"/>
        <location filename="form_run.cpp" line="707"/>
        <location filename="form_run.cpp" line="724"/>
        <source>Start</source>
        <translation>Пуск</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="773"/>
        <source>Loading</source>
        <translation>Загрузка</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="576"/>
        <location filename="form_run.cpp" line="790"/>
        <source>G-code is loaded</source>
        <translation>G-код загружен</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="587"/>
        <location filename="form_run.cpp" line="805"/>
        <source>Load G-code error</source>
        <translation>Ошибка загрузки G-кода</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation type="vanished">Реверс</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="696"/>
        <location filename="form_run.cpp" line="707"/>
        <location filename="form_run.cpp" line="724"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="696"/>
        <location filename="form_run.cpp" line="707"/>
        <location filename="form_run.cpp" line="724"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="691"/>
        <source>Start cutting</source>
        <translation>Начать рез</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="690"/>
        <source>Start/Stop running</source>
        <translation>Начать/остановить работу</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="692"/>
        <source>Stop cutting</source>
        <translation>Остановить рез</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="697"/>
        <location filename="form_run.cpp" line="708"/>
        <location filename="form_run.cpp" line="725"/>
        <source>Go to back</source>
        <translation>Двигаться в обратную сторону</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="697"/>
        <location filename="form_run.cpp" line="708"/>
        <location filename="form_run.cpp" line="725"/>
        <source>Cancel program</source>
        <translation>Отменить программу</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="718"/>
        <location filename="form_run.cpp" line="735"/>
        <location filename="form_run.cpp" line="747"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <source>Make a pause</source>
        <translation type="vanished">Сделать паузу</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="741"/>
        <source>Shortcut</source>
        <translation>Коротко</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="742"/>
        <source>Fast return to start position</source>
        <translation>Быстрый возврат на начальную позицию</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="742"/>
        <location filename="form_run.cpp" line="754"/>
        <source>Reset CNC</source>
        <translation>Сброс ЧПУ</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="753"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
</context>
<context>
    <name>FormSettings</name>
    <message>
        <source>Options</source>
        <oldsource>&lt;h2&gt;Options&lt;/h2&gt;</oldsource>
        <translation type="vanished">Настройки</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="58"/>
        <source>Application settings</source>
        <translation>Настройки программы</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="59"/>
        <source>CNC parameters</source>
        <oldsource>&lt;h3&gt;CNC parameters&lt;/h3&gt;</oldsource>
        <translation>Параметры работы ЧПУ</translation>
    </message>
    <message>
        <source>Swap plot axes X, Y</source>
        <translation type="vanished">Поменять местами оси X, Y на чертеже</translation>
    </message>
    <message>
        <source>Reverse plot axis X</source>
        <oldsource>Reverse X axis</oldsource>
        <translation type="vanished">Изменить направление оси X на чертеже</translation>
    </message>
    <message>
        <source>Reverse plot axis Y</source>
        <oldsource>Reverse Y axis</oldsource>
        <translation type="vanished">Изменить направление оси Y на чертеже</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="71"/>
        <source>Show plot axes names</source>
        <oldsource>Show plot axes</oldsource>
        <translation>Отображать оси на чертеже</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="73"/>
        <source>Input Levels, bits</source>
        <oldsource>Input Levels, bits: </oldsource>
        <translation>Входные уровни, биты</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="81"/>
        <source>Metal</source>
        <translation>Металл</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="82"/>
        <source>Stone</source>
        <translation>Камень</translation>
    </message>
    <message>
        <source>Servomotors enable</source>
        <translation type="vanished">Включение серводвигателей</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="85"/>
        <source>Reverse motor X</source>
        <oldsource>Invert motor X</oldsource>
        <translation>Изменить направление оси X в ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="86"/>
        <source>Reverse motor Y</source>
        <oldsource>Invert motor Y</oldsource>
        <translation>Изменить направление оси Y в ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="92"/>
        <source>Reverse motor U</source>
        <translation>Изменить направление оси U в ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="93"/>
        <source>Reverse motor V</source>
        <translation>Изменить направление оси V в ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="87"/>
        <source>Swap motors X and Y</source>
        <translation>Поменять местами оси X и Y в ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="10"/>
        <source>CNC Settings</source>
        <translation>Настройки ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="90"/>
        <source>Use servomotors</source>
        <oldsource>Enable servomotors</oldsource>
        <translation>Использовать сервоприводы</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="105"/>
        <source>Use linear encoders for X, Y axes</source>
        <oldsource>Enable XY linear encoders</oldsource>
        <translation>Использовать линейные энкодеры для осей X, Y</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="94"/>
        <source>Swap motors U and V</source>
        <translation>Поменять местами оси U и V в ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="108"/>
        <source>Reverse Encoder X</source>
        <translation>Изменить направление энкодера X</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="109"/>
        <source>Reverse Encoder Y</source>
        <translation>Изменить направление энкодера Y</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="118"/>
        <source>Acceleration</source>
        <translation>Ускорение</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="121"/>
        <location filename="form_settings.cpp" line="128"/>
        <source>um/sec2</source>
        <translation>мкм/сек2</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="125"/>
        <source>Deceleration</source>
        <translation>Торможение</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="133"/>
        <source>Feedback enable</source>
        <translation>Включить обратную связь</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="138"/>
        <source>High threshold</source>
        <translation>Верхний порог</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="144"/>
        <source>Low threshold</source>
        <oldsource>Middle threshold</oldsource>
        <translation>Нижний порог</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="150"/>
        <source>Rollback timeout</source>
        <translation>Время ожидания отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="156"/>
        <source>Rollback attempts</source>
        <translation>Количество попыток отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="161"/>
        <source>Rollback length</source>
        <translation>Длина отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="169"/>
        <source>Rollback speed</source>
        <translation>Скорость отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="612"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="613"/>
        <source>Go to the Home panel</source>
        <translation>Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="653"/>
        <source>Open Help</source>
        <translation>Открыть помощь</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="142"/>
        <location filename="form_settings.cpp" line="148"/>
        <source>V</source>
        <translation>В</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="154"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="165"/>
        <location filename="form_settings.cpp" line="202"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="173"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="196"/>
        <source>Calculation step</source>
        <translation>Шаг вычислений</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="vanished">Отладка</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="83"/>
        <source>Debug</source>
        <translation>Отладка</translation>
    </message>
    <message>
        <source>Calculation step, mm</source>
        <oldsource>Step, mm: </oldsource>
        <translation type="vanished">Шаг вычислений, мм</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="210"/>
        <source>Precision (steps/mm)</source>
        <oldsource>Scale (steps/mm)</oldsource>
        <translation>Точность (шагов/мм)</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="211"/>
        <source>Motor</source>
        <translation>Двигатель</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="235"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="vanished">Назад</translation>
    </message>
    <message>
        <source>Return to the Home panel</source>
        <oldsource>Back to the home panel</oldsource>
        <translation type="vanished">Вернуться на главную панель</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="616"/>
        <source>Read</source>
        <translation>Чтение</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="617"/>
        <source>Read settings from CNC</source>
        <translation>Прочитать настройки из ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="619"/>
        <source>Write</source>
        <translation>Запись</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="620"/>
        <source>Write settings</source>
        <translation>Записать настройки</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="622"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="623"/>
        <source>Set default settings</source>
        <oldsource>Default settings</oldsource>
        <translation>Установить настройки по умолчанию</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="652"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormTest</name>
    <message>
        <location filename="formtest.ui" line="14"/>
        <source>Form</source>
        <translation>Тест</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="31"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="38"/>
        <source>Quick Test</source>
        <translation>Быстрый</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="45"/>
        <source>Full Test</source>
        <translation>Полный</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="52"/>
        <source>Imitation</source>
        <translation>Иммитация</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="59"/>
        <source>Read CNC</source>
        <translation>Чтение ЧПУ</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="66"/>
        <source>Memtest</source>
        <translation>Память</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="126"/>
        <source>Reconnect</source>
        <translation>Повт. соед.</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="133"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="140"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="17"/>
        <source>Diagnostics</source>
        <oldsource>Diagnostic panel</oldsource>
        <translation>Диагностика</translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="22"/>
        <source>Go to the Home panel</source>
        <translation>Перейти на главную панель</translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="106"/>
        <location filename="form_test.cpp" line="112"/>
        <source>Error: No G-code program</source>
        <oldsource>Error: No G-code program
</oldsource>
        <translation>Ошибка: Нет программы G-код</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>Главное окно</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="122"/>
        <source>Warning</source>
        <oldsource>Warning: </oldsource>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="127"/>
        <source>Error</source>
        <oldsource>Error: </oldsource>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="164"/>
        <source>Meatec</source>
        <translation>Меатэк</translation>
    </message>
    <message>
        <source>Load DXF contours</source>
        <translation type="vanished">Загрузка контуров DXF</translation>
    </message>
    <message>
        <source>Code Editor</source>
        <oldsource>Code Edit Page</oldsource>
        <translation type="vanished">Редактор G-код</translation>
    </message>
    <message>
        <source>Centering</source>
        <translation type="vanished">Центровка</translation>
    </message>
    <message>
        <source>Cutting settings</source>
        <translation type="vanished">Параметры реза</translation>
    </message>
    <message>
        <source>Run Page</source>
        <translation type="vanished">Рабочая панель</translation>
    </message>
    <message>
        <source>Job Panel</source>
        <translation type="vanished">Рабочая панель</translation>
    </message>
    <message>
        <source>CNC Settigns</source>
        <translation type="vanished">Настройки ЧПУ</translation>
    </message>
    <message>
        <source>CNC Pult</source>
        <translation type="vanished">Пульт ЧПУ</translation>
    </message>
    <message>
        <source>Test</source>
        <oldsource>Test Page</oldsource>
        <translation type="vanished">Тестирование</translation>
    </message>
    <message>
        <source>Home Panel</source>
        <oldsource>Home Page</oldsource>
        <translation type="vanished">Главная панель</translation>
    </message>
    <message>
        <source>Passes Panel</source>
        <oldsource>Passes Page</oldsource>
        <translation type="vanished">Панель параметров реза</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="vanished">Помощь</translation>
    </message>
</context>
<context>
    <name>ModeTableModel</name>
    <message>
        <location filename="mode_table_model.cpp" line="16"/>
        <source>Drum Velocity</source>
        <translation>Скорость барабана</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="17"/>
        <source>Pulse Width</source>
        <translation>Ширина импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="18"/>
        <source>Pulse Ratio</source>
        <translation>Скважность импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="19"/>
        <source>Voltage Level</source>
        <translation>Уровень напряжения</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="20"/>
        <source>Current Level</source>
        <translation>Уровень тока</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="27"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>NewCutlineDialog</name>
    <message>
        <location filename="new_cutline_dialog.cpp" line="43"/>
        <source>Abs</source>
        <translation>Абс.</translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="44"/>
        <source>Rel</source>
        <translation>Отн.</translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="88"/>
        <source>New cutline</source>
        <translation>Новая линия захода</translation>
    </message>
</context>
<context>
    <name>PultWidget</name>
    <message>
        <location filename="pult_widget.cpp" line="67"/>
        <location filename="pult_widget.cpp" line="341"/>
        <source>Motor</source>
        <translation>Двигатель</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="68"/>
        <location filename="pult_widget.cpp" line="342"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="79"/>
        <source>Forward</source>
        <translation>Вперёд</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="81"/>
        <source>Move forward a distance dX, dY</source>
        <translation>Перемещение вперёд на расстояние dX, dY</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="83"/>
        <source>Move forward a distance dX, dY, dU, dV</source>
        <translation>Перемещение вперёд на расстояние dX, dY, dU, dV</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="86"/>
        <source>Reverse</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="88"/>
        <source>Move backward a distance -dX, -dY</source>
        <translation>Перемещение назад на расстояние -dX,- dY</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="90"/>
        <source>Move backward a distance -dX, -dY, -dU, -dV</source>
        <translation>Перемещение назад на расстояние -dX, -dY, -dU, -dV</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="93"/>
        <source>Copy</source>
        <translation>Копия</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="94"/>
        <source>Copy the current CNC position into the according task fields</source>
        <oldsource>Copy current CNC position into the according fields</oldsource>
        <translation>Скопировать текущую позицию ЧПУ в соответствующие поля задачи</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="96"/>
        <source>Remain</source>
        <translation>Остаток</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="97"/>
        <source>Calculate the remain to continue moving from the current position</source>
        <oldsource>Calculate the remain and continue moving from current position</oldsource>
        <translation>Рассчитать остаток для продолжения движения с текущей позиции</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="105"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="106"/>
        <source>Clear dX, dY, X, Y fields</source>
        <translation>Очистить поля  dX, dY, X, Y</translation>
    </message>
    <message>
        <source>Clear X, Y fields</source>
        <translation type="vanished">Очистить поля X, Y</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="108"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="109"/>
        <source>Reset scales</source>
        <translation>Сброс масштаба</translation>
    </message>
    <message>
        <source>Moving</source>
        <oldsource>Movement</oldsource>
        <translation type="vanished">Перемещение</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="343"/>
        <location filename="pult_widget.cpp" line="533"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="344"/>
        <location filename="pult_widget.cpp" line="534"/>
        <source>steps</source>
        <translation>шагов</translation>
    </message>
    <message>
        <source>Diff.</source>
        <translation type="vanished">Диф.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="vanished">Назад</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="423"/>
        <source>Workpiece</source>
        <translation>Заготовка</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="424"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <source>HV</source>
        <translation type="vanished">ВН</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="426"/>
        <source>Shunt</source>
        <translation>Шунт</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="454"/>
        <source>Cancel</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="455"/>
        <source>Cancel current process</source>
        <translation>Остановить перемещение</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="vanished">Стоп</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="458"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="460"/>
        <source>Holding of stepper motors on/off</source>
        <translation>Вкл./выкл. удержание шаговых двигателей</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="66"/>
        <source>Scale (steps/mm)</source>
        <translation>Масштаб (шагов/мм)</translation>
    </message>
    <message>
        <source>Go</source>
        <translation type="vanished">Старт</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="421"/>
        <source>Discharge Gap</source>
        <translation>Искровой зазор</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="422"/>
        <source>Reverse Voltage</source>
        <translation>Обратное напр.</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="425"/>
        <source>High Voltage</source>
        <translation>Высокое напр.</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="65"/>
        <source>Move</source>
        <translation>Старт</translation>
    </message>
    <message>
        <source>Relative movement on dX, dY with given speed</source>
        <translation type="vanished">Начать перемещение на расстояние dX, dY с заданной скоростью</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="100"/>
        <source>Set</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="101"/>
        <source>Set position X, Y</source>
        <translation>Установить счетчики положения в значения X, Y</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">Применить</translation>
    </message>
    <message>
        <source>Apply scale</source>
        <translation type="vanished">Применить масштаб</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="546"/>
        <source>Speed</source>
        <oldsource>Speed:</oldsource>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="553"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="554"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="36"/>
        <source>Meatec CNC</source>
        <translation>ЧПУ Меатэк</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="705"/>
        <source>CNC</source>
        <translation>ЧПУ</translation>
    </message>
    <message>
        <source>from</source>
        <translation type="vanished">от</translation>
    </message>
    <message>
        <source>on</source>
        <translation type="vanished">от</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="706"/>
        <source>built on</source>
        <translation>от</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="708"/>
        <source>at</source>
        <translation>на</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="710"/>
        <source>MHz</source>
        <translation>МГц</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="713"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>MCU reset source</source>
        <translation type="vanished">Источник сброса мк</translation>
    </message>
    <message>
        <location filename="fpga.cpp" line="153"/>
        <source>FPGA</source>
        <translation>ПЛИС</translation>
    </message>
    <message>
        <location filename="fpga.h" line="32"/>
        <source>stone</source>
        <translation>камнерез</translation>
    </message>
</context>
<context>
    <name>ResizeDialog</name>
    <message>
        <location filename="resize_dialog.cpp" line="4"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="5"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="6"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="7"/>
        <source>New size</source>
        <translation>Новый размер</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="19"/>
        <location filename="resize_dialog.cpp" line="26"/>
        <location filename="resize_dialog.cpp" line="33"/>
        <location filename="resize_dialog.cpp" line="40"/>
        <location filename="resize_dialog.cpp" line="96"/>
        <location filename="resize_dialog.cpp" line="103"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="88"/>
        <source>Center</source>
        <translation>Центр</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="138"/>
        <source>Resize</source>
        <translation>Изменение размеров</translation>
    </message>
</context>
<context>
    <name>RotateDialog</name>
    <message>
        <location filename="rotate_dialog.cpp" line="5"/>
        <source>Angle</source>
        <translation>Угол</translation>
    </message>
    <message>
        <location filename="rotate_dialog.cpp" line="51"/>
        <source>Rotate</source>
        <translation>Поворот</translation>
    </message>
</context>
<context>
    <name>RunWidget</name>
    <message>
        <location filename="run_widget.cpp" line="45"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="47"/>
        <source>Holding of stepper motors on/off</source>
        <translation>Вкл./выкл. удержание шаговых двигателей</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="50"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation type="vanished">Реверс</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="50"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="50"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="50"/>
        <source>Start cutting</source>
        <translation>Начать рез</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="50"/>
        <source>Go to back</source>
        <translation>Двигаться в обратную сторону</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="50"/>
        <source>Cancel program</source>
        <translation>Отменить программу</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="52"/>
        <source>Speed</source>
        <oldsource>Speed:</oldsource>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="58"/>
        <source>Enter</source>
        <translation>Ввод</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="59"/>
        <source>Enter speed</source>
        <translation>Записать скорость в ЧПУ</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="67"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="68"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="70"/>
        <source>Idle run</source>
        <translation>Холостой ход</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="134"/>
        <source>Time</source>
        <translation>Прошло</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="135"/>
        <source>Remain</source>
        <translation>Осталось</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="273"/>
        <source>Encoders</source>
        <translation>Энкодеры</translation>
    </message>
    <message>
        <source>EncX</source>
        <translation type="vanished">Энкодер X</translation>
    </message>
    <message>
        <source>EncY</source>
        <translation type="vanished">Энкодер Y</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="207"/>
        <source>Discharge Gap</source>
        <translation>Искровой зазор</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="208"/>
        <source>Reverse Voltage</source>
        <translation>Обратное напр.</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="211"/>
        <source>High Voltage</source>
        <translation>Высокое напр.</translation>
    </message>
    <message>
        <source>Diff.</source>
        <translation type="vanished">Диф.</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="209"/>
        <source>Workpiece</source>
        <translation>Заготовка</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="210"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <source>HV</source>
        <translation type="vanished">ВН</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="212"/>
        <source>Shunt</source>
        <translation>Шунт</translation>
    </message>
</context>
<context>
    <name>SlicingWidget</name>
    <message>
        <location filename="slicing_widget.cpp" line="10"/>
        <source>Slicing</source>
        <oldsource>Workpiece slicing</oldsource>
        <translation>Нарезка заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="11"/>
        <source>Wire diameter</source>
        <translation>Диаметр проволоки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="12"/>
        <location filename="slicing_widget.cpp" line="163"/>
        <source>Workpiece width</source>
        <translation>Ширина заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="13"/>
        <source>Spacing</source>
        <translation>Свободное пространство</translation>
    </message>
    <message>
        <source>Slicing step</source>
        <translation type="vanished">Шаг нарезки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="14"/>
        <source>Step</source>
        <translation>Шаг</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="14"/>
        <source>signed value</source>
        <translation>число со знаком</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="15"/>
        <source>Slices number</source>
        <translation>Количество частей</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="16"/>
        <source>Sections number in the speed profile</source>
        <translation>Количество участков в профиле скорости</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="17"/>
        <location filename="slicing_widget.cpp" line="164"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="24"/>
        <location filename="slicing_widget.cpp" line="33"/>
        <location filename="slicing_widget.cpp" line="42"/>
        <location filename="slicing_widget.cpp" line="51"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="60"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="80"/>
        <source>Workpiece profile</source>
        <translation>Профиль заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="81"/>
        <source>Rectangle</source>
        <translation>Прямоугольный</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="82"/>
        <source>Circle</source>
        <translation>Круглый</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="90"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="92"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="96"/>
        <source>Axis</source>
        <translation>Ось</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="107"/>
        <source>Undo</source>
        <translation>Откат</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="108"/>
        <source>Return last working values</source>
        <translation>Вернуть рабочие последние значения</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="110"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="111"/>
        <source>Set default values</source>
        <translation>Установить значения по умолчанию</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="113"/>
        <source>Generate</source>
        <translation>Генерировать</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="114"/>
        <source>Generate contour</source>
        <translation>Генерировать контур</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="169"/>
        <source>Workpiece diameter</source>
        <translation>Диаметр заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="170"/>
        <source>Average speed</source>
        <translation>Средняя скорость</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="284"/>
        <location filename="slicing_widget.cpp" line="287"/>
        <source>Slicing generate error</source>
        <translation>Ошибка генерации нарезки</translation>
    </message>
</context>
<context>
    <name>SlotsWidget</name>
    <message>
        <location filename="slots_widget.cpp" line="12"/>
        <source>Slots</source>
        <translation>Прорези</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="13"/>
        <source>Wire diameter</source>
        <translation>Диаметр проволоки</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="14"/>
        <source>Slots depth</source>
        <translation>Глубина прорезей</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="14"/>
        <location filename="slots_widget.cpp" line="15"/>
        <source>signed value</source>
        <translation>число со знаком</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="15"/>
        <source>Step</source>
        <translation>Шаг</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="16"/>
        <source>Slots number</source>
        <translation>Количество прорезей</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="17"/>
        <source>Cut speed</source>
        <translation>Скорость реза</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="18"/>
        <source>Idle speed</source>
        <oldsource>Rollback speed</oldsource>
        <translation>Скорость холостого хода</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="19"/>
        <source>Drum velocity</source>
        <translation>Скорость барабана</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="20"/>
        <source>Idle drum velocity</source>
        <oldsource>Rollback drum velocity</oldsource>
        <translation>Скорость барабана при холостом ходе</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="24"/>
        <location filename="slots_widget.cpp" line="34"/>
        <location filename="slots_widget.cpp" line="44"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="61"/>
        <location filename="slots_widget.cpp" line="71"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="89"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="91"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="95"/>
        <source>Axis</source>
        <translation>Ось</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="107"/>
        <source>Undo</source>
        <translation>Откат</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="108"/>
        <source>Return last working values</source>
        <translation>Вернуть последние рабочие значения</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="110"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="111"/>
        <source>Set default values</source>
        <translation>Установить значения по умолчанию</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="113"/>
        <source>Generate</source>
        <translation>Генерировать</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="114"/>
        <source>Generate contour</source>
        <translation>Генерировать контур</translation>
    </message>
    <message>
        <location filename="slots_widget.cpp" line="273"/>
        <location filename="slots_widget.cpp" line="276"/>
        <source>Slots generate error</source>
        <translation>Ошибка генерации прорезей</translation>
    </message>
</context>
<context>
    <name>UVSizingWidget</name>
    <message>
        <location filename="uv_sizing_widget.cpp" line="10"/>
        <source>Measuring</source>
        <translation>Измерение</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="12"/>
        <source>Wire diameter</source>
        <translation>Диаметр проволоки</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="13"/>
        <source>UV-axes maximum value</source>
        <translation>Максимальное значение по осям UV</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="14"/>
        <source>Distance between rollers</source>
        <translation>Расстояние между роликами</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="15"/>
        <source>Workpiece bottom height</source>
        <translation>Высота низа заготовки</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="16"/>
        <source>Workpiece thickness</source>
        <translation>Толщина заготовки</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="17"/>
        <source>Roller diameter</source>
        <translation>Диаметр ролика</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="18"/>
        <source>Roller plane</source>
        <translation>Плоскость ролика</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="19"/>
        <source>Entry line length</source>
        <translation>Длина линии захода</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="102"/>
        <source>Cut direction</source>
        <translation>Направление реза</translation>
    </message>
    <message>
        <source>Cutline length</source>
        <translation type="vanished">Длина линии захода</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="21"/>
        <source>Generate</source>
        <translation>Генерировать</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="23"/>
        <location filename="uv_sizing_widget.cpp" line="28"/>
        <source>Recalculate</source>
        <translation>Пересчёт</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="25"/>
        <source>Measuring top diameter</source>
        <translation>Измеренные верхний диаметр</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="26"/>
        <source>Measuring bot diameter</source>
        <translation>Измеренный нижний диаметр</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="30"/>
        <source>Result</source>
        <translation>Результат</translation>
    </message>
    <message>
        <location filename="uv_sizing_widget.cpp" line="37"/>
        <location filename="uv_sizing_widget.cpp" line="45"/>
        <location filename="uv_sizing_widget.cpp" line="53"/>
        <location filename="uv_sizing_widget.cpp" line="61"/>
        <location filename="uv_sizing_widget.cpp" line="69"/>
        <location filename="uv_sizing_widget.cpp" line="77"/>
        <location filename="uv_sizing_widget.cpp" line="96"/>
        <location filename="uv_sizing_widget.cpp" line="141"/>
        <location filename="uv_sizing_widget.cpp" line="149"/>
        <location filename="uv_sizing_widget.cpp" line="166"/>
        <location filename="uv_sizing_widget.cpp" line="175"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <source>Axis and direction</source>
        <translation type="vanished">Ось и направление</translation>
    </message>
</context>
</TS>
